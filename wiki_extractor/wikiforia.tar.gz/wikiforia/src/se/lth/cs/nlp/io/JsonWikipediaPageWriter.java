/**
 * This file is part of Wikiforia.
 *
 * Wikiforia is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Wikiforia is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Foobar.  If not, see <http://www.gnu.org/licenses/>.
 */
package se.lth.cs.nlp.io;

import org.codehaus.stax2.XMLOutputFactory2;
import org.codehaus.stax2.XMLStreamWriter2;
import se.lth.cs.nlp.mediawiki.model.WikipediaPage;
import se.lth.cs.nlp.pipeline.Sink;

import javax.xml.stream.XMLStreamException;
import java.io.*;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.List;

/**
 * WikipediaPage UTF-8 XML writer, only writes WikipediaPages with content
 */
public class JsonWikipediaPageWriter implements Sink<WikipediaPage> {
    private final File output;
    private FileChannel fileChannel;

    /**
     * Default constructor
     * @param output which file to write to
     */
    public JsonWikipediaPageWriter(File output) {
        try {
            File outputFile = new File(output.getAbsoluteFile(), "wikiOutput.json");
            outputFile.createNewFile();
            this.fileChannel = FileChannel.open(Paths.get(outputFile.toURI()), StandardOpenOption.WRITE, StandardOpenOption.TRUNCATE_EXISTING);
            //this.fileChannel.write(ByteBuffer.wrap("[".getBytes("utf-8")));
            this.fileChannel.write(ByteBuffer.wrap("\n".getBytes("utf-8")));
            this.output = output;
        } catch (FileNotFoundException e) {
            throw new IOError(e);
        } catch (IOException e) {
            throw new IOError(e);
        }
    }

    @Override
    public synchronized void process(List<WikipediaPage> batch) {
        if(fileChannel == null)
            return;

        try {
            if(batch.size() == 0) {
                this.fileChannel.write(ByteBuffer.wrap("\n".getBytes("utf-8")));
                //fileChannel.write(ByteBuffer.wrap("]".getBytes("utf-8")));
                this.fileChannel.close();
                this.fileChannel = null;
                System.out.println("Closing file: " + output.getAbsolutePath() + File.separatorChar + output.getName());
                return;
            }

            for (WikipediaPage wikipediaPage : batch) {

                if(wikipediaPage.getText().length() > 0) {                      
                   ///{"id": "12", "url": "https://en.wikipedia.org/wiki?curid=12", "title": "Anarchism"}

                    fileChannel.write(ByteBuffer.wrap("{".getBytes("utf-8")));
                    fileChannel.write(ByteBuffer.wrap(("\"id\": " + "\"" + String.valueOf(wikipediaPage.getId()) + "\", ").getBytes("utf-8")));
                    fileChannel.write(ByteBuffer.wrap(("\"title\": " + "\"" + String.valueOf(wikipediaPage.getTitle()).replace("\\", "\\\\") .replace("\"", "\\\"") + "\", ").getBytes("utf-8")));
                    fileChannel.write(ByteBuffer.wrap(("\"url\": " + "\"https://en.wikipedia.org/wiki?curid=" + String.valueOf(wikipediaPage.getId() + "\"")).getBytes("utf-8")));
                    fileChannel.write(ByteBuffer.wrap("}".getBytes("utf-8")));
                    fileChannel.write(ByteBuffer.wrap("\n".getBytes("utf-8")));                  
                }
            }
        } catch (IOException e) {
            throw new IOError(e);
        }
    }

    @Override
    public String toString() {
        return String.format("XML Writer { target: %s }", output.getAbsolutePath());
    }
}
